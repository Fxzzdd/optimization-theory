%主函数
syms x1 x2;
f = 10*(x2-x1)^2 + (1-x1)^2;
[x_optimization,f_optimization] = Trust_Region_Method(f,[0 0],0.1,0.3,0.7,[x1 x2]);
x_optimization = double(x_optimization);
f_optimization = double(f_optimization);
x_optimization
f_optimization

%function Trust_Region_Method（信赖域算法）
function [x_optimization,f_optimization] = Trust_Region_Method(f,x0,r0,mu,eta,var_x,epsilon)
format long;
%   f：目标函数
%   x0：初始点
%   r0：初始信赖域半径
%   eta：参数
%   epsilon：精度
%   x_optimization：目标函数取最小值时的自变量值
%   f_optimization：目标函数的最小值
if nargin == 6
    epsilon = 1.0e-6;
end
x0 = transpose(x0);
var_x = transpose(var_x);
rk = r0;
k = 0;
xk = x0;
grad_fxk = 1;
while norm(grad_fxk) > epsilon
    grad_fx = jacobian(f,var_x);
    grad2_fx = jacobian(grad_fx,var_x);
    fxk = subs(f,var_x,xk);
    grad_fxk  = subs(grad_fx,var_x,xk);
    grad2_fxk = subs(grad2_fx,var_x,xk);  
    double_grad2_fxk = double(grad2_fxk);
    grad_fxk_T = transpose(grad_fxk);
    double_grad_fxk_T = double(grad_fxk_T);
    lb = -rk*ones(length(var_x),1);
    ub = rk*ones(length(var_x),1);
    [y_star,phi_y_star]= quadprog(double_grad2_fxk,double_grad_fxk_T,[],[],[],[],lb,ub);           %   二次规划
    fxk_y_star = subs(grad_fx,var_x,xk + y_star);
    rho = (fxk - fxk_y_star)/(fxk - phi_y_star);
    if rho <= mu
        rk_next = 0.5*rk;
        xk_next = xk;
    else
        rk_next = rk;
        xk_next = xk + y_star;
        if rho >= eta
            rk_next = 2*rk;
        end
    end
    k = k + 1;
    rk = rk_next;
    xk = xk_next;   
end
x_optimization = xk;
f_optimization = subs(f,var_x,x_optimization);
format short;