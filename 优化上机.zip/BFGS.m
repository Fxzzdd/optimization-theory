clc; 
clear all;
x0=[3,-1,0,1]';
[x,val,k]=bfgs('powell','dpowell',x0);
%Powell奇异函数
function y=powell(x)
y=(x(1)+10*x(2))^2+5*(x(3)-10*x(4))^2+(x(2)-2*x(3))^2+10*(x(1)-x(4))^2;
end
%导函数
function y=dpowell(x)
y=[2*(x(1)+10*x(2))+20*(x(1)-x(4));
20*(x(1)+10*x(2))+2*(x(2)-2*x(3));
10*(x(3)-10*x(4))-4*(x(2)-2*x(3));
-100*(x(3)-10*x(4))-20*(x(1)-x(4))];
end
%bfgs算法
function [x,val,k]=bfgs(fun,gfun,x0,varargin)
maxk=500;   %最大迭代次数
rho=0.55; sigma1=0.4; epsilon1=1e-5;
k=0;   n=length(x0);
Bk=eye(n);   %Bk=feval('Hess',x0);
while(k<maxk)
    gk=feval(gfun,x0,varargin{:});
    if(norm(gk)<epsilon1), break; end  
    dk=-Bk\gk;  
    m=0; mk=0;
    while(m<20)
        newf=feval(fun,x0+rho^m*dk,varargin{:});
        oldf=feval(fun,x0,varargin{:});
        if(newf<oldf+sigma1*rho^m*gk'*dk)
            mk=m; break;
        end
        m=m+1;
    end
    x=x0+rho^mk*dk;  
    sk=x-x0;  yk=feval(gfun,x,varargin{:})-gk;
    if(yk'*sk>0)
        Bk=Bk-(Bk*sk*sk'*Bk)/(sk'*Bk*sk)+(yk*yk')/(yk'*sk);
    end
    k=k+1;     x0=x;
end
val=feval(fun,x0,varargin{:});
end