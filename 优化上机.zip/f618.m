clc;
clear;%清除区
a = -1;b = 5; %初始区间
f = @(x) exp(-x)+x^2; %创建题目的匿名函数，可以进行修改，其余函数分别为3*x^4-4*x^3-12*x^2, x^4+2*x+5, x^3-3*x+1
eps = 0.0001; %区间精度
while((b - a) >= eps)
    x1 = a + 0.382 * (b - a);
    x2 = a + 0.618 * (b - a); %0.618法主要步骤
    if f(x1) < f(x2) 
        b = x2;
    else
        a = x1;
    end
end
x = (a + b) / 2; %得到满足条件的最优解
disp(['最优解： x = ',num2str(x)]);
disp(['最优值: f(x) = ',num2str(f(x))]);%输出
