clc;
clear;%清除区
f=@(x)exp(-x)+x^2; %创建题目的匿名函数，可以进行修改，其余函数分别为3*x^4-4*x^3-12*x^2, x^4+2*x+5, x^3-3*x+1
[x,fx]=Fibonacci(f,[0 2],1e-4)
function [x,result]=Fibonacci(f,x0,delta) %x0储存极值所在区间
x3=x0(2);
x0=x0(1);
F=[1 1]; %Fibonacci数列的前两个数为1
n=3; %从第三个数开始继续加入
while F(end) < (x3-x0)/delta  %生成Fibonacci契数列
    F(n)=F(n-1)+F(n-2);
    n=n+1;
end
n=n-1; %while循环最后多加了一个数，这里减一刚好就是Fibonacci数列元素的个数
x1=x0+F(n-2)/F(n)*(x3-x0);
x2=x0+F(n-1)/F(n)*(x3-x0);
while n > 3 
    if f(x1) > f(x2)
        n=n-1; %执行一次，Fibonacci数列向前推一个数
        x0=x1;
        x1=x2;
        x2=x0+F(n-1)/F(n)*(x3-x0);
    else
        n=n-1;
        x3=x2;
        x2=x1;
        x1=x0+F(n-2)/F(n)*(x3-x0);
    end
end
x=(x0+x3)/2;
result=f(x);
end
