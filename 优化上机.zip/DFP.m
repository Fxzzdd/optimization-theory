function DFP()
	syms x1 x2 x3 x4 t;
	f=(x1+10*x2)^2+5*(x3-10*x4)^2+(x2-2*x3)^2+10*(x1-x4)^2;
	fx1=diff(f,x1);%求表达式f对xi的一阶求导
	fx2=diff(f,x2);
	fx3=diff(f,x3);
	fx4=diff(f,x4);
	fi=[fx1 fx2 fx3 fx4];
	x0=[3,-1,0,1];%构造函数f的梯度函数 
    %初始点的梯度和函数值  
	f0=subs(f,[x1 x2 x3 x4],x0);
	g0=subs(fi,[x1 x2 x3 x4],x0);
	H0=eye(4);
	xk=x0;
	fk=f0;
	gk=g0;
	Hk=H0;
	k=1;
	while(norm(gk)>1e-6)%设定判断值
		pk=-Hk*gk';
		xk=xk+t*pk';
		f_t=subs(f,[x1 x2 x3 x4],xk);
		df_t=diff(f_t,t);
		tk=solve(df_t);
		xk=subs(xk,t,tk);
		fk=subs(f,[x1 x2 x3 x4],xk);
		gk0=gk;
		gk=subs(fi,[x1 x2 x3 x4],xk);
		yk=gk-gk0;
		sk=tk*pk';
		Hk=Hk+sk'*sk/(yk*sk')-(Hk*yk'*yk*Hk)/(yk*Hk*yk');
		k=k+1;
        k
        xk%跳出作为记录
    end
    % xk
end